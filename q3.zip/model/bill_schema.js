const mongoose = require("mongoose");
const billSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  mobile: {
    type: Number,
    required: true,
  },
  orders: {
    type: Array,
    required: true,
  },
});
module.exports = mongoose.model("bill", billSchema);
