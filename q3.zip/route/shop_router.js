const express = require("express");
const route = express.Router();
const shopdata = require("../model/shop_schema");

// insert product in s_product
route.post("/ins_prod", (req, res) => {
  const entry = new shopdata({
    id: req.body.id,
    product: req.body.product,
    size: req.body.size,
    price: req.body.price,
    qty: req.body.qty,
    img: req.body.img,
  });
  entry.save();
  res.send();
});

// get all products
route.get("/getproducts", async (req, res) => {
  const data = await shopdata.find();
  res.send(data);
});

module.exports = route;
