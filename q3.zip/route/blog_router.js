const express = require("express");
const route = express.Router();
const blogdata = require("../model/blog_schema");
// const req = require("express/lib/request");

// Insert data
route.post("/insdata", (req, res) => {
  const entry = new blogdata({
    id: req.body.id,
    topic: req.body.tp,
    desc: req.body.des,
  });
  entry.save();
  res.send();
});

// display
route.get("/disprecord", async (req, res) => {
  const data = await blogdata.find();
  res.send(data);
});

//distinct
route.get("/getdistinct", async (req, res) => {
  const data = await blogdata.distinct("topic");
  res.send(data);
});

//getrec by topic
route.get("/getrec/:type", async (req, res) => {
  const data = await blogdata.find({ topic: req.params.type });
  res.send(data);
});
module.exports = route;
