const express = require("express");
const route = express.Router();
const productdata = require("../model/product_schema");

route.post("/insertProduct", (req, res) => {
  try {
    const entry = new productdata({
      id: req.body.id,
      pname: req.body.pname,
      price: req.body.price,
      qty: req.body.qty,
    });
    entry.save();
    res.send();
  } catch (error) {
    console.log(error);
  }
});

// get all products
route.get("/getProduct", async (req, res) => {
  const data = await productdata.find();
  res.send(data);
});

module.exports = route;
