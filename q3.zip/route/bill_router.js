const express = require("express");
const route = express.Router();
const billdata = require("../model/bill_schema");

route.post("/insbill", async (req, res) => {
  const entry = new billdata({
    name: req.body.name,
    mobile: req.body.mobile,
    orders: req.body.data,
  });
  entry.save();
  res.send();
});

// get all bills
route.get("/getbills", async (req, res) => {
  const data = await billdata.find();
  res.send(data);
});

// search bill
route.get("/searchrec/:key", async (req, res) => {
  let data = await billdata.find({
    $or: [
      { name: { $regex: req.params.key } },
      //   { mobile: { $regex: req.params.key } },
    ],
  });
  res.send(data);
});

module.exports = route;
