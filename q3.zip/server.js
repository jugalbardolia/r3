const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const blogroute = require("./route/blog_router");
const productRoute = require("./route/product_router");
const billroute = require("./route/bill_router");
const shoproute = require("./route/shop_router");

const app = express();
mongoose.connect("mongodb://127.0.0.1:27017/demo");
app.use(express.json());
app.use(cors());
app.use("/blog", blogroute);
app.use("/product", productRoute);
app.use("/bill", billroute);
app.use("/shop", shoproute);

app.listen(3004, () => {
  console.log("server running on 3004");
});
