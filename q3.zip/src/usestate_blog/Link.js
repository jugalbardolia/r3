import React, { useState } from "react";

const Link = () => {
  return (
    <div>
      <h1>useState Blog</h1>
      {/* <Nav /> */}
    </div>
  );
};

export default Link;
