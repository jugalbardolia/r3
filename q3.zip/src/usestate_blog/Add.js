import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Nav from "./Nav";

const Add = () => {
  const [id, setid] = useState("");
  const [tp, settp] = useState("");
  const [des, setdes] = useState("");

  let navigate = useNavigate();

  function getid(e) {
    e.preventDefault();
    setid(e.target.value);
  }

  function gettp(e) {
    e.preventDefault();
    settp(e.target.value);
  }

  function getdes(e) {
    e.preventDefault();
    setdes(e.target.value);
  }
  const collectdata = async () => {
    try {
      let insdata = axios.post(`http://localhost:3004/blog/insdata`, {
        id,
        tp,
        des,
      });
      if (insdata) {
        navigate("/ublog/all");
      }
    } catch (error) {
      console.log(error);
    }
  };
  //   function onhandle(e) {
  //     e.preventDefault();
  //     let ob = { id: id, topic: tp, desc: des };
  //     getdata(ob);
  //     setid("");
  //     setdes("");
  //     settp("");
  //   }
  return (
    <div>
      <Nav />
      <form class="mt-5">
        <div class="row mb-3">
          <label class="col-sm-2 ms-5 col-form-label">Id</label>
          <div class="col-6">
            <input
              type="text"
              class="form-control"
              value={id}
              onChange={getid}
            />
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 ms-5 col-form-label">Topic</label>
          <div class="col-6">
            <input
              type="text"
              class="form-control"
              value={tp}
              onChange={gettp}
            />
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 ms-5 col-form-label">Description</label>
          <div class="col-6">
            <textarea
              type="text"
              class="form-control"
              value={des}
              onChange={getdes}
            />
          </div>
        </div>
        <button
          type="submit"
          class="btn ms-5 btn-primary"
          onClick={collectdata}
        >
          Add Blog
        </button>
      </form>
    </div>
  );
};

export default Add;
