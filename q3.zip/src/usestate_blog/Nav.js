import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import axios from "axios";

const Nav = () => {
  const [data, setdata] = useState([]);

  useEffect(() => {
    getdata();
  }, []);
  const getdata = async () => {
    try {
      let res = await axios.get(`http://localhost:3004/blog/getdistinct`);
      setdata(res.data);
    } catch (error) {
      console.log(error);
    }
  };

  const gettype = data.map((d) => {
    return (
      <li className="nav-item">
        <NavLink className={"nav-link"} to={`/ublog/disp/${d}`}>
          {d}
        </NavLink>
      </li>
    );
  });

  return (
    <div>
      <div>
        <ul className="nav nav-tabs">
          <li className="nav-item">
            <NavLink className="nav-link" to={"/ublog/all"}>
              All
            </NavLink>
          </li>
          {gettype}
          <li className="nav-item">
            <NavLink className="nav-link" to={"/ublog/add"}>
              Add Blog
            </NavLink>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Nav;
