import axios from "axios";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Nav from "./Nav";

const Display = () => {
  const [data, setdata] = useState([]);
  const params = useParams();

  useEffect(() => {
    getdata();
  }, [params.type]);

  const getdata = async () => {
    try {
      if (params.type) {
        let res = await axios.get(
          `http://localhost:3004/blog/getrec/${params.type}`
        );
        setdata(res.data);
      } else {
        let res = await axios.get(`http://localhost:3004/blog/disprecord`);
        setdata(res.data);
      }
    } catch (error) {
      console.log(error);
    }
  };

  const blog_data = data.map((s) => {
    return (
      <div className="">
        <div class="p-4 p-md-5 mb-4 rounded text-body-emphasis bg-warning">
          <div class="col-lg-6 px-0">
            <h1>{s.id}</h1>
            <h1 class="display-4 fst-italic">{s.topic}</h1>
            <p class="lead my-3">{s.desc}</p>
            <p class="lead mb-0">
              <a href="#" class="text-body-emphasis fw-bold">
                Continue reading...
              </a>
            </p>
          </div>
        </div>
      </div>
    );
  });

  return (
    <div>
      <Nav />
      {blog_data}
    </div>
  );
};

export default Display;
