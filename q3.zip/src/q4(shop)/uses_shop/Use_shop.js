import React, { useState } from "react";
import Nav from "./Nav";
import { Route, Routes } from "react-router-dom";
import Product from "./Product";
import Addtocart from "./Addtocart";

const Use_shop = () => {
  const [cart, setcart] = useState([]);
  function getcart(ms) {
    setcart(cart.concat(ms));
  }
  function getfc(ms) {
    setcart(ms);
  }
  return (
    <div>
      <h3>Usestate Shopping</h3>
      <Nav cart={cart} />
      <Routes>
        <Route
          path="/product"
          element={<Product getcart={getcart}></Product>}
        ></Route>
        <Route
          path="/addtocart"
          element={<Addtocart cart={cart} getfc={getfc} />}
        ></Route>
      </Routes>
    </div>
  );
};

export default Use_shop;
