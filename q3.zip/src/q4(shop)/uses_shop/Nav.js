import React from "react";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";

const Nav = ({ cart }) => {
  return (
    <div>
      <div>
        <ul className="nav nav-tabs">
          <li className="nav-item">
            <NavLink className="nav-link" to={"/product"}>
              Home
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to={"/addtocart"}>
              Add Blog ({cart.length})
            </NavLink>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Nav;
