import React, { useEffect, useState } from "react";
import axios from "axios";

const Product = ({ getcart }) => {
  const [data, setdata] = useState([]);
  useEffect(() => {
    getdata();
  }, []);

  const getdata = async () => {
    let res = await axios.get(`http://localhost:5050/students/getproducts`);
    setdata(res.data);
  };

  return (
    <div>
      <h5>This is Product page</h5>
      <div class="row">
        {data.map((s) => {
          return (
            <div class="col-4 p-4">
              <div class="card" style={{ width: "20rem" }}>
                <img
                  src={s.img}
                  style={{ height: 100 }}
                  class="card-img-top"
                  alt="..."
                />
                <div class="card-body">
                  {/* <h5 class="card-title">{s.id}</h5> */}
                  <p class="card-text">Product name :{s.product}</p>
                  <p class="card-text">Size : {s.size}</p>
                  <p class="card-text">Price :{s.price}</p>
                  {/* <p class="card-text">{s.product}</p> */}
                  <button
                    class="btn btn-primary"
                    onClick={() => {
                      getcart(s);
                    }}
                  >
                    Add to cart
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Product;
