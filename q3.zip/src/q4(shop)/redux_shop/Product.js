import React, { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addtocart, fetchdata } from "./shopslice";
import axios from "axios";

const Product = () => {
  const data = useSelector((state) => state.shop.data);

  useEffect(() => {
    getdata();
  }, []);

  const getdata = async () => {
    const res = await axios.get(`http://localhost:5050/students/getproducts`);
    dispatch(fetchdata(res.data));
  };

  const dispatch = useDispatch();
  return (
    <div>
      <h2>This is product page</h2>
      {
        <div class="row">
          {data.map((s) => {
            return (
              <div class="col-4 p-4">
                <div class="card" style={{ width: "20rem" }}>
                  <img
                    src={s.img}
                    class="card-img-top"
                    style={{ height: 100 }}
                    alt="..."
                  />
                  <div class="card-body">
                    {/* <h5 class="card-title">{s.id}</h5> */}
                    <p class="card-text">Product Name:{s.product}</p>
                    <p class="card-text">Size :{s.size}</p>
                    <p class="card-text">Price :{s.price}</p>
                    {/* <p class="card-text">{s.product}</p> */}
                    <button
                      class="btn btn-primary"
                      onClick={() => {
                        dispatch(addtocart(s));
                      }}
                    >
                      Add to cart
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      }
    </div>
  );
};

export default Product;
