import React from 'react'
import Nav from './Nav'
import {Routes,Route} from 'react-router-dom'

import Addtocart from './Addtocart'
import Product from './Product'

const Redux_shop = () => {
  return (
    <div>
      <h2>redux Shopping</h2>
      <Nav/>
      <Routes>
                <Route path='/product' element={<Product/>}/>
                <Route path='/addtocart' element={<Addtocart/>}/>
        </Routes>
    </div>
  )
}

export default Redux_shop
