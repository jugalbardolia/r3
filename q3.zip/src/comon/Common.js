import React from "react";
import { NavLink } from "react-router-dom";

const Common = () => {
  return (
    <div>
      <div>
        <ul className="nav nav-tabs">
          <li className="nav-item">
            <NavLink className="nav-link" to={"/ublog"}>
              Usestate Blog
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to={"/"}>
              Redux Blog
            </NavLink>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default Common;
