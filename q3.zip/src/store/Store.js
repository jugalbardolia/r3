import { configureStore } from "@reduxjs/toolkit";
import billReducer from "../redux_bill/billslice.js";
import blogReducer from "../redux_blog/blogslice";
import shopReducer from "../q4(shop)/redux_shop/shopslice.js";

export const store = configureStore({
  reducer: {
    bill: billReducer,
    blog: blogReducer,
    shop: shopReducer,
  },
});
