import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { adddata } from "./blogslice";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Add = () => {
  const [id, setid] = useState("");
  const [tp, settop] = useState("");
  const [des, setdesc] = useState("");
  const navigate = useNavigate();

  const collectdata = async () => {
    try {
      let insdata = axios.post(`http://localhost:3004/blog/insdata`, {
        id,
        tp,
        des,
      });
      if (insdata) {
        navigate("/home");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h4>This is addpage</h4>
      <form class="mt-5">
        <div class="row mb-3">
          <label class="col-sm-2 ms-5 col-form-label">Id</label>
          <div class="col-6">
            <input
              type="text"
              name="id"
              class="form-control"
              onChange={(e) => {
                setid(e.target.value);
              }}
            />
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 ms-5 col-form-label">Topic</label>
          <div class="col-6">
            <input
              type="text"
              name="topic"
              class="form-control"
              onChange={(e) => {
                settop(e.target.value);
              }}
            />
          </div>
        </div>
        <div class="row mb-3">
          <label class="col-sm-2 ms-5 col-form-label">Description</label>
          <div class="col-6">
            <textarea
              type="text"
              name="desc"
              class="form-control"
              onChange={(e) => {
                setdesc(e.target.value);
              }}
            />
          </div>
        </div>
        <button
          type="button"
          class="btn ms-5 btn-primary"
          onClick={() => {
            collectdata();
          }}
        >
          Add Blog
        </button>
      </form>
    </div>
  );
};

export default Add;
