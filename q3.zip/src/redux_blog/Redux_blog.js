import React from "react";
import { Route, Routes } from "react-router-dom";
import Nav from "./Nav";
import Home from "./Home";
import Add from "./Add";

const Redux_blog = () => {
  return (
    <div>
      <h4>Redux Blog</h4>
      <Nav />
      <Routes>
        <Route path="/home" element={<Home />}></Route>
        <Route path="/add" element={<Add />}></Route>
        <Route path="/home/:type" element={<Home />}></Route>
      </Routes>
    </div>
  );
};

export default Redux_blog;
