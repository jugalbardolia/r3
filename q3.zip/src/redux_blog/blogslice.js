import { createSlice } from "@reduxjs/toolkit";

export const blogslice = createSlice({
  name: "blog",
  initialState: {
    data: [],
    type: [],
  },
  reducers: {
    fetchdata: (state, ms) => {
      state.data = ms.payload;
    },
    fetchtype: (state, ms) => {
      state.type = ms.payload;
    },
  },
});

// console.log(blogslice.data);
export const { fetchdata, fetchtype } = blogslice.actions;
export default blogslice.reducer;
