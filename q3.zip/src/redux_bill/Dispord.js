import axios from "axios";
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchdata, getbills } from "./billslice";

const Dispord = () => {
  const bills = useSelector((state) => state.bill.bills);
  const dispatch = useDispatch();

  useEffect(() => {
    getdata();
  }, []);

  // get all bills
  const getdata = async () => {
    let res = await axios.get(`http://localhost:5050/students/getbills`);
    dispatch(getbills(res.data));
  };

  //search

  const searchdata = async (e) => {
    let key = e.target.value;
    if (key) {
      let res = await axios.get(`http://localhost:5050/students/searchrec/${key}`);
      dispatch(getbills(res.data));
    } else {
      getdata();
    }
  };

  //   disp all bills
  const dispbills = bills.map((b) => {
    var total = 0;
    return (
      <tr>
        <td>{b.name}</td>
        <td>{b.mobile}</td>
        <td>
          <table className="table ">
            <thead>
              <th>Product name</th>
              <th>price</th>
              <th>qty</th>
              <th>total</th>
            </thead>
            <tbody>
              {b.orders.map((o) => {
                total += o.qty * o.price;
                return (
                  <tr>
                    <td>{o.pname}</td>
                    <td>{o.price}</td>
                    <td>{o.qty}</td>
                    <td>{o.qty * o.price}</td>
                  </tr>
                );
              })}
              <tr>
                <td colSpan={3}>Total Amount</td>
                <td>{total}</td>
              </tr>
            </tbody>
          </table>
        </td>
      </tr>
    );
  });

  console.log(bills);
  return (
    <div>
      <h1>this is disp</h1>
      Search :{" "}
      <input
        type="text"
        onChange={(e) => {
          searchdata(e);
        }}
      ></input>
      <table >
        <thead>
          <tr>
            <th scope="col">Name</th>
            <th scope="col">Mobile no</th>
            <th scope="col">Orders</th>
          </tr>
        </thead>
        <tbody>{dispbills}</tbody>
      </table>
    </div>
  );
};

export default Dispord;
